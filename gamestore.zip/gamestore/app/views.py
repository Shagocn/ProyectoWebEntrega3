from django.shortcuts import render

from .models import Producto,Genero
# Create your views here.

def index(request):
    productos= Producto.objects.all()
    context={"productos":productos}
    return render(request, 'app/index.html', context)

def crud(request):
    productos = Producto.objects.all()
    context = {"productos": productos}
    return render(request, 'app/productos_list.html', context)

def productosAdd(request):
    if request.method is not "POST":
        generos=Genero.objects.all()
        context={"generos":generos}
        return render(request, 'app/productos_add.html', context)
    else:
        nombre=request.POST["nombre"]
        precio=request.POST["precio"]
        plataforma=request.POST["Plataforma"]
        fecha_lanzamiento=request.POST["fecha_lanzamiento"]
        genero=request.POST["genero"]
        activo="1"

        objGenero=Genero.objects.get(genero = genero)
        obj=Producto.objects.create(nombre=nombre,
                                    precio=precio,
                                    plataforma=plataforma,
                                    fecha_lanzamiento=fecha_lanzamiento,
                                    genero=objGenero,
                                    activo=1 )
    obj.save()
    context={"mensaje":"¡Producto ingresado correctamente!"}
    return render(request, 'app/productos_add.html', context)

def home(request):
    return render(request, 'app/home.html')

def carrito(request):
    return render(request, 'app/carrito.html')

def categorias(request):
    return render(request, 'app/categorias.html')

def compras(request):
    return render(request, 'app/compras.html')

def novedades(request):
    return render(request, 'app/novedades.html')

def ofertas(request):
    return render(request, 'app/ofertas.html')





def accion(request):
    return render(request, 'app/categorias/accion.html')

def arcade(request):
    return render(request, 'app/categorias/arcade.html')

def aventura(request):
    return render(request, 'app/categorias/aventura.html')

def deportes(request):
    return render(request, 'app/categorias/deportes.html')

def estrategia(request):
    return render(request, 'app/categorias/estrategia.html')

def RPG(request):
    return render(request, 'app/categorias/RPG.html')

def shooter(request):
    return render(request, 'app/categorias/shooter.html')

def simulacion(request):
    return render(request, 'app/categorias/simulacion.html')

def varios(request):
    return render(request, 'app/categorias/varios.html')


def forgot(request):
    return render(request, 'app/user/forgot.html')

def login(request):
    return render(request, 'app/user/login.html')

def register(request):
    return render(request, 'app/user/register.html')

def reset(request):
    return render(request, 'app/user/reset.html')



def game1(request):
    return render(request, 'app/juegos/game1.html')

def game2(request):
    return render(request, 'app/juegos/game2.html')

def game3(request):
    return render(request, 'app/juegos/game3.html')


