from django.db import models

# Create your models here.

class Genero(models.Model):
    genero = models.CharField(max_length=20, blank=False, null=False)
    
    def __str__(self):
        return str(self.genero)

class Producto(models.Model):
    nombre = models.CharField(max_length=20)
    precio = models.CharField(primary_key=True, max_length=7)
    plataforma = models.CharField(max_length=20)
    fecha_lanzamiento = models.DateField(blank=False, null=False)
    genero = models.ForeignKey('Genero',on_delete=models.CASCADE)

    def __str__(self):
        return str(self.nombre)+", "+str(self.plataforma)