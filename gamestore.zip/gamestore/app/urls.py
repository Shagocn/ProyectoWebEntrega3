from django.urls import path
from .views import home, carrito, categorias, compras, novedades, ofertas, accion, arcade, aventura, deportes, estrategia, RPG, shooter, simulacion, varios, forgot, login, register, reset, game1, game2, game3
from . import views


urlpatterns = [
    path('index', views.index, name='index'),
    
    path('', home, name="home"),
    path('carrito/', carrito, name="carrito"),
    path('categorias/', categorias, name="categorias"),
    path('compras/', compras, name="compras"),
    path('novedades/', novedades, name="novedades"),
    path('ofertas/', ofertas, name="ofertas"),

    path('categorias/accion', accion, name="accion"),
    path('categorias/arcade', arcade, name="arcade"),
    path('categorias/aventura', aventura, name="aventura"),
    path('categorias/deportes', deportes, name="deportes"),
    path('categorias/estrategia', estrategia, name="estrategia"),
    path('categorias/RPG', RPG, name="RPG"),
    path('categorias/shooter', shooter, name="shooter"),
    path('categorias/simulacion', simulacion, name="simulacion"),
    path('categorias/varios', varios, name="varios"),

    path('user/forgot', forgot, name="forgot"),
    path('user/login', login, name="login"),
    path('user/register', register, name="register"),
    path('user/reset', reset, name="reset"),
    
    path('juegos/game1', game1, name="game1"),
    path('juegos/game2', game2, name="game2"),
    path('juegos/game3', game3, name="game3"),

    path('crud', views.crud, name='crud'),
    path('productosAdd', views.productosAdd, name='productosAdd'),
]
